#include "multimedia-object.h"
#include <string.h>
#include <stdio.h>

static Date createDate(int j, int m, int a)
{
    Date d;
    d.year = a;
    d.day = j;
    d. month = m;
    return d;
}

void fillMO (MultimediaObject * o, char * name, char * path, int day, int month, int year, TypeMultimediaObject type)
{
    /* to be completed*/
}

#include "test.h"
/*!
* \brief  Unit testing of the functions provided in the multimedia-object.c file
*/
void test_MO()
{
	printf("Tests unitaires du module multimedia-object :\n");
	/* To be completed*/
}

